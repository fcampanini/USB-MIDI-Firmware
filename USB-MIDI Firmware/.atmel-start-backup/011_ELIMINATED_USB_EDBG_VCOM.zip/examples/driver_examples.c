/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

/**
 * Example of using USART_USB_VCOM to write "Hello World" using the IO abstraction.
 */
void USART_USB_VCOM_example(void)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&USART_USB_VCOM, &io);
	usart_sync_enable(&USART_USB_VCOM);

	io_write(io, (uint8_t *)"Hello World!", 12);
}

static struct timer_task TIMER_Service_task1, TIMER_Service_task2;

/**
 * Example of using TIMER_Service.
 */
static void TIMER_Service_task1_cb(const struct timer_task *const timer_task)
{
}

static void TIMER_Service_task2_cb(const struct timer_task *const timer_task)
{
}

void TIMER_Service_example(void)
{
	TIMER_Service_task1.interval = 100;
	TIMER_Service_task1.cb       = TIMER_Service_task1_cb;
	TIMER_Service_task1.mode     = TIMER_TASK_REPEAT;
	TIMER_Service_task2.interval = 200;
	TIMER_Service_task2.cb       = TIMER_Service_task2_cb;
	TIMER_Service_task2.mode     = TIMER_TASK_REPEAT;

	timer_add_task(&TIMER_Service, &TIMER_Service_task1);
	timer_add_task(&TIMER_Service, &TIMER_Service_task2);
	timer_start(&TIMER_Service);
}

static struct timer_task TIMER_USB_TX_task1, TIMER_USB_TX_task2;

/**
 * Example of using TIMER_USB_TX.
 */
static void TIMER_USB_TX_task1_cb(const struct timer_task *const timer_task)
{
}

static void TIMER_USB_TX_task2_cb(const struct timer_task *const timer_task)
{
}

void TIMER_USB_TX_example(void)
{
	TIMER_USB_TX_task1.interval = 100;
	TIMER_USB_TX_task1.cb       = TIMER_USB_TX_task1_cb;
	TIMER_USB_TX_task1.mode     = TIMER_TASK_REPEAT;
	TIMER_USB_TX_task2.interval = 200;
	TIMER_USB_TX_task2.cb       = TIMER_USB_TX_task2_cb;
	TIMER_USB_TX_task2.mode     = TIMER_TASK_REPEAT;

	timer_add_task(&TIMER_USB_TX, &TIMER_USB_TX_task1);
	timer_add_task(&TIMER_USB_TX, &TIMER_USB_TX_task2);
	timer_start(&TIMER_USB_TX);
}
