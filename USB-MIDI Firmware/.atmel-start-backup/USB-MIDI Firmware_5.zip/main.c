#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	gpio_set_pin_level(LED_PWR, true);

	/* Replace with your application code */
	while (1) {
	}
}
