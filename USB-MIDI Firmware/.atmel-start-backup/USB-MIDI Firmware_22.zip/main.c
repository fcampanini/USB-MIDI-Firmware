#include <atmel_start.h>

/*################################ PROTOTYPES AND VARIABLES##################################*/

/*------------------------------TIMER_SERVICE---------------------------------------------*/
static struct timer_task TIMER_Service_task1, TIMER_Service_task2;
static void TIMER_Service_task1_cb(const struct timer_task *const timer_task);
static void TIMER_Service_task2_cb(const struct timer_task *const timer_task);
static void TIMER_Service_Load(void);
/*----------------------------------------------------------------------------------------*/

/*####################################### MAIN #############################################*/
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	TIMER_Service_Load();
	
	gpio_set_pin_level(LED_PWR, true);

	/* Replace with your application code */
	while (1) {
	}
}


/*#################################### EVENT HANDLERS ######################################*/

/*------------------------------TIMER_SERVICE---------------------------------------------*/
static void TIMER_Service_task1_cb(const struct timer_task *const timer_task)
{
	gpio_toggle_pin_level(LED_PULSE);
}

static void TIMER_Service_task2_cb(const struct timer_task *const timer_task)
{
}
/*----------------------------------------------------------------------------------------*/

/*#################################### INITIALIZATIONS ######################################*/

/*------------------------------TIMER_SERVICE---------------------------------------------*/
void TIMER_Service_Load(void)
{
	TIMER_Service_task1.interval = 1000;
	TIMER_Service_task1.cb       = TIMER_Service_task1_cb;
	TIMER_Service_task1.mode     = TIMER_TASK_REPEAT;
	TIMER_Service_task2.interval = 200;
	TIMER_Service_task2.cb       = TIMER_Service_task2_cb;
	TIMER_Service_task2.mode     = TIMER_TASK_REPEAT;

	timer_add_task(&TIMER_Service, &TIMER_Service_task1);
	timer_add_task(&TIMER_Service, &TIMER_Service_task2);
	timer_start(&TIMER_Service);
}
/*----------------------------------------------------------------------------------------*/